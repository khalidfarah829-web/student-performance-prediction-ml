
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error

# -----------------------------
# Step 1: Load the dataset
# -----------------------------
# Make sure 'student_data.csv' is in the same folder as this script
data = pd.read_csv("student_data.csv")

# Display first 5 rows to verify
print("Dataset Preview:\n", data.head())

# -----------------------------
# Step 2: Define features and target
# -----------------------------
X = data[['StudyHours', 'Attendance', 'PreviousScore']]  # Input features
y = data['FinalScore']  # Target variable

# -----------------------------
# Step 3: Split data into training and testing sets
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -----------------------------
# Step 4: Linear Regression Model
# -----------------------------
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Predict on test set
lr_predictions = lr_model.predict(X_test)

# Evaluate model performance
lr_error = mean_absolute_error(y_test, lr_predictions)
print("\nLinear Regression Mean Absolute Error:", lr_error)

# -----------------------------
# Step 5: Decision Tree Regressor
# -----------------------------
dt_model = DecisionTreeRegressor(random_state=42)
dt_model.fit(X_train, y_train)

# Predict on test set
dt_predictions = dt_model.predict(X_test)

# Evaluate model performance
dt_error = mean_absolute_error(y_test, dt_predictions)
print("Decision Tree Mean Absolute Error:", dt_error)

# -----------------------------
# Step 6: Visualizations
# -----------------------------
# Linear Regression Predictions
plt.scatter(y_test, lr_predictions, color='blue')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')  # Reference line
plt.xlabel("Actual Final Score")
plt.ylabel("Predicted Final Score")
plt.title("Linear Regression Predictions")
plt.show()

# Decision Tree Predictions
plt.scatter(y_test, dt_predictions, color='green')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')  # Reference line
plt.xlabel("Actual Final Score")
plt.ylabel("Predicted Final Score")
plt.title("Decision Tree Predictions")
plt.show()

